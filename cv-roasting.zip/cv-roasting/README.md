# CV Roasting 🔥

Upload CV (PDF/DOCX) → AI ("Mas Erdi") kasih roasting tajam tapi actionable: skor CV, kekuatan, kelemahan, contoh perbaikan bullet, dan keyword yang kelewat — disesuaikan dengan target posisi yang diisi user.

- Frontend: React + Vite
- Ekstraksi teks PDF/DOCX: 100% di browser (pdfjs-dist + mammoth), file tidak pernah diupload ke server dalam bentuk asli
- Backend: 1 serverless function (`/api/roast.js`) yang manggil Anthropic API dengan API key kamu, supaya key tidak kebuka di browser

## Cara deploy (dari HP, tanpa CLI)

### 1. Upload ke GitHub

Buka repo baru di GitHub lewat browser HP kamu → tombol **Add file > Upload files** → drag semua file & folder project ini sekaligus (GitHub sekarang support upload folder utuh, termasuk subfolder `src/` dan `api/`). Commit.

Struktur akhir di repo harus seperti ini:
```
├── api/
│   └── roast.js
├── src/
│   ├── App.jsx
│   ├── FlameGauge.jsx
│   ├── extractText.js
│   ├── index.css
│   └── main.jsx
├── .gitignore
├── index.html
├── package.json
└── vite.config.js
```

### 2. Import ke Vercel

1. Buka vercel.com → **Add New > Project** → pilih repo GitHub ini.
2. Framework preset akan otomatis kedeteksi **Vite** — biarkan default.
3. **Sebelum deploy**, buka bagian **Environment Variables**, tambahkan:
   - Key: `ANTHROPIC_API_KEY`
   - Value: API key Anthropic kamu (dari console.anthropic.com)
4. Klik **Deploy**.

Setiap kali kamu edit file lewat GitHub web editor dan commit ke branch utama, Vercel otomatis re-deploy.

### 3. Selesai

Buka URL `.vercel.app` yang diberikan — upload CV, isi target posisi, klik "Roasting Sekarang".

## Kalau mau ganti model AI

Model diatur di `api/roast.js`, baris `const MODEL = "claude-sonnet-5";`. Ganti ke model lain kalau perlu.

## Catatan biaya

Setiap klik "Roasting Sekarang" = 1 panggilan API (dikenakan biaya sesuai tarif API Anthropic kamu). Tidak ada limit bawaan di kode ini — kalau mau batasi pemakaian publik, bisa ditambah rate-limit sederhana di `api/roast.js` nanti.
